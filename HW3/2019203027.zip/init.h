#ifndef __INIT_H__
#define __INIT_H__

void Init(void);

#endif // __INIT_H__